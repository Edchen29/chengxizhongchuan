using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlServerCe;

namespace SqlCE2005_Demo
{
    public partial class Form1 : Form
    {    

        System.Data.SqlServerCe.SqlCeConnection cn;
        string SQL;	//.Engine
        System.Data.SqlServerCe.SqlCeEngine SQLEngine;

        public Form1()
        {
            InitializeComponent();
        }

        public void CreateDB()
        {
            if (System.IO.File.Exists("\\My Documents\\Northwind1.sdf"))
            {
                System.IO.File.Delete("\\My Documents\\Northwind1.sdf");
            }

            // If the database does not already exist, then create it.
            if (!System.IO.File.Exists("\\My Documents\\Northwind1.sdf"))
            {
                SQLEngine = new System.Data.SqlServerCe.SqlCeEngine("data source=\\My Documents\\Northwind1.sdf");
                SQLEngine.CreateDatabase();

                // Next, open the database; 
                //Provider=Microsoft.SQLServer.OLEDB.CE.2.0��SqlCeConnection�м���Provider=...����������
                cn = new System.Data.SqlServerCe.SqlCeConnection("Data Source=\\My Documents\\Northwind1.sdf");
                cn.Open();                         

                // Now, through a series of SQL statements create the structure of the database.
                // Create the Customers table.
                SQL = "CREATE TABLE myTable (ID uint Primary Key NOT NULL,Timestamp datetime NOT NULL,Name nvarchar(40) NOT NULL,Value float NOT NULL)";
                System.Data.SqlServerCe.SqlCeCommand cmd = new System.Data.SqlServerCe.SqlCeCommand(SQL, cn);
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();

                SQL = "INSERT INTO myTable (ID, Timestamp, Name, Value) VALUES (1,'2007-08-05 08:10:09','Main.Var1',12.98)";
                cmd.CommandText = SQL;
                cmd.ExecuteNonQuery();

                // Close the database.
                cn.Close();
               
            }
        }

        private void LoadmyTable()
        {
            System.Data.SqlServerCe.SqlCeConnection cn;
            System.Data.SqlServerCe.SqlCeCommand cmd;
            System.Data.SqlServerCe.SqlCeDataReader dtr;

            uint ID;
            string SQL;
            DateTime Timestamp;
            ListViewItem LVItem;
            string Name;
            float Value;   
      
             int i;
      

            // Open the database.  Provider=Microsoft.SQLSERVER.OLEDB.CE.2.0;
            cn = new System.Data.SqlServerCe.SqlCeConnection("data source=\\My Documents\\Northwind1.sdf");
            //Data Source=\My Documents\Northwind.sdf")
            cn.Open();

            // Retrieve a list of the customers.
            cmd = new System.Data.SqlServerCe.SqlCeCommand("SELECT * FROM myTable", cn);
            dtr = cmd.ExecuteReader();

            for (i = 1; i < dtr.FieldCount; i++)
            {
                txtShow.Text = dtr.GetName(i) + "   ";
            }           

           while (dtr.Read()) 
           {            
               
                   txtShow.Text = txtShow.Text + dtr.GetValue(i)+ "     ";
                   
                 
               
            //LVItem.Text = dtr.FieldCount(("Table");
            //ID = dtr.Read("ID");
            //LVItem.SubItems.Add(ID.ToString);
            //Timestamp = dtr("Timestamp");
            //LVItem.SubItems.Add(Timestamp.ToString("N2"));
            //Value = dtr("Value");
            //LVItem.SubItems.Add(Discount.ToString("N2"));          
        

            }          

            // Clean-up.
            dtr.Close();
            cn.Close();         

        }
            ////====================================================================
            //File.Delete("Test.sdf");
            //string connString = "Data Source='Test.sdf'; LCID=1033;   Password=\"s$;2'!dS64\"; Encrypt = TRUE;";
            //SqlCeEngine engine = new SqlCeEngine(connString);
            //engine.CreateDatabase();
        private void FormatListView()
        {
            // This routine handles configuring the listview control.
            //lvwOrder.View = View.Details;           
            //lvwOrder.Columns.Add("ID", 60, HorizontalAlignment.Left);
            //lvwOrder.Columns.Add("Timestamp", 120, HorizontalAlignment.Right);
            //lvwOrder.Columns.Add("Name", 60, HorizontalAlignment.Right);
            //lvwOrder.Columns.Add("Value", 60, HorizontalAlignment.Right);           

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CreateDB();

           //Format the ListView control.
            //FormatListView();

            //Load the Customer combo box.
            LoadmyTable();
        }

    }
}