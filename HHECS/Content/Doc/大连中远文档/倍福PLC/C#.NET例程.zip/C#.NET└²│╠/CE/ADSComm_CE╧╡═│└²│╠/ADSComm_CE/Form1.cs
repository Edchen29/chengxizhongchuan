using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using TwinCAT.Ads;
using System.IO;

namespace ADSComm_CE
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //============ADS ͨѶ====================================				
        private int[] hConnect;
        private AdsStream dataStream;
        private BinaryReader binRead;
        private TcAdsClient tcClient;
        
        //====================================

        private void Form1_Load(object sender, EventArgs e)
        {
            //===========����ADSͨѶ����=======

			tcClient = new TcAdsClient();	
			tcClient.Connect(801);        
						
		}

        private void timer1_Tick(object sender, EventArgs e)
        {
            //========�ڴ���Program����ʾ����===================

            txtbData0.Text = tcClient.ReadAny(0x4020, 0, typeof(Boolean)).ToString();
            txtbData1.Text = tcClient.ReadAny(0x4020, 1, typeof(Boolean)).ToString();
            txtbData2.Text = tcClient.ReadAny(0x4020, 2, typeof(Boolean)).ToString();
            txtbData3.Text = tcClient.ReadAny(0x4020, 3, typeof(Boolean)).ToString();
            txtbData4.Text = tcClient.ReadAny(0x4020, 4, typeof(Boolean)).ToString();

            txtIData0.Text = tcClient.ReadAny(0xF030, 0, typeof(Int16)).ToString();
            txtIData1.Text = tcClient.ReadAny(0xF030, 2, typeof(Int16)).ToString();
            txtIData2.Text = tcClient.ReadAny(0xF030, 4, typeof(Int16)).ToString();
            txtIData3.Text = tcClient.ReadAny(0xF030, 6, typeof(Int16)).ToString();
            txtIData4.Text = tcClient.ReadAny(0xF030, 8, typeof(Int16)).ToString();
            
        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer1.Interval = 500;
        }

        private void btnStopRead_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            UInt16 uiData;            

            //inputPanel1.Enabled = true; //Shows the input panel window.            

            if (System.Text.RegularExpressions.Regex.IsMatch(txtSet.Text, @"[^0-9.]"))
            {
                MessageBox.Show("����������");
            }
            else
            {
                uiData = UInt16.Parse(txtSet.Text);
                tcClient.WriteAny(0x4020, 500, uiData);
            }
        }
    }
}