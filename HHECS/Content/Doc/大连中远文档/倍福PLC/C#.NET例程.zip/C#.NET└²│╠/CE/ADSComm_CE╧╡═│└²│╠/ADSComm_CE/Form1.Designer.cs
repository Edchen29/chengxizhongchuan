﻿namespace ADSComm_CE
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.Label6 = new System.Windows.Forms.Label();
            this.lbliData = new System.Windows.Forms.Label();
            this.txtbData4 = new System.Windows.Forms.TextBox();
            this.txtbData3 = new System.Windows.Forms.TextBox();
            this.txtbData2 = new System.Windows.Forms.TextBox();
            this.txtbData1 = new System.Windows.Forms.TextBox();
            this.txtbData0 = new System.Windows.Forms.TextBox();
            this.txtIData4 = new System.Windows.Forms.TextBox();
            this.txtIData3 = new System.Windows.Forms.TextBox();
            this.txtIData2 = new System.Windows.Forms.TextBox();
            this.txtIData1 = new System.Windows.Forms.TextBox();
            this.txtIData0 = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer();
            this.btnRead = new System.Windows.Forms.Button();
            this.btnStopRead = new System.Windows.Forms.Button();
            this.txtSet = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Label6
            // 
            this.Label6.Location = new System.Drawing.Point(7, 58);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(100, 16);
            this.Label6.Text = "bData[0..4]";
            this.Label6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lbliData
            // 
            this.lbliData.Location = new System.Drawing.Point(7, 86);
            this.lbliData.Name = "lbliData";
            this.lbliData.Size = new System.Drawing.Size(100, 16);
            this.lbliData.Text = "iData[0..4]";
            this.lbliData.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txtbData4
            // 
            this.txtbData4.Location = new System.Drawing.Point(575, 58);
            this.txtbData4.Name = "txtbData4";
            this.txtbData4.Size = new System.Drawing.Size(92, 23);
            this.txtbData4.TabIndex = 14;
            // 
            // txtbData3
            // 
            this.txtbData3.Location = new System.Drawing.Point(459, 58);
            this.txtbData3.Name = "txtbData3";
            this.txtbData3.Size = new System.Drawing.Size(92, 23);
            this.txtbData3.TabIndex = 15;
            // 
            // txtbData2
            // 
            this.txtbData2.Location = new System.Drawing.Point(343, 58);
            this.txtbData2.Name = "txtbData2";
            this.txtbData2.Size = new System.Drawing.Size(92, 23);
            this.txtbData2.TabIndex = 16;
            // 
            // txtbData1
            // 
            this.txtbData1.Location = new System.Drawing.Point(227, 58);
            this.txtbData1.Name = "txtbData1";
            this.txtbData1.Size = new System.Drawing.Size(92, 23);
            this.txtbData1.TabIndex = 17;
            // 
            // txtbData0
            // 
            this.txtbData0.Location = new System.Drawing.Point(111, 58);
            this.txtbData0.Name = "txtbData0";
            this.txtbData0.Size = new System.Drawing.Size(92, 23);
            this.txtbData0.TabIndex = 18;
            // 
            // txtIData4
            // 
            this.txtIData4.Location = new System.Drawing.Point(575, 86);
            this.txtIData4.Name = "txtIData4";
            this.txtIData4.Size = new System.Drawing.Size(92, 23);
            this.txtIData4.TabIndex = 19;
            // 
            // txtIData3
            // 
            this.txtIData3.Location = new System.Drawing.Point(459, 86);
            this.txtIData3.Name = "txtIData3";
            this.txtIData3.Size = new System.Drawing.Size(92, 23);
            this.txtIData3.TabIndex = 20;
            // 
            // txtIData2
            // 
            this.txtIData2.Location = new System.Drawing.Point(343, 86);
            this.txtIData2.Name = "txtIData2";
            this.txtIData2.Size = new System.Drawing.Size(92, 23);
            this.txtIData2.TabIndex = 21;
            // 
            // txtIData1
            // 
            this.txtIData1.Location = new System.Drawing.Point(227, 86);
            this.txtIData1.Name = "txtIData1";
            this.txtIData1.Size = new System.Drawing.Size(92, 23);
            this.txtIData1.TabIndex = 22;
            // 
            // txtIData0
            // 
            this.txtIData0.Location = new System.Drawing.Point(111, 86);
            this.txtIData0.Name = "txtIData0";
            this.txtIData0.Size = new System.Drawing.Size(92, 23);
            this.txtIData0.TabIndex = 23;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btnRead
            // 
            this.btnRead.Location = new System.Drawing.Point(153, 175);
            this.btnRead.Name = "btnRead";
            this.btnRead.Size = new System.Drawing.Size(126, 29);
            this.btnRead.TabIndex = 24;
            this.btnRead.Text = "开始读取";
            this.btnRead.Click += new System.EventHandler(this.btnRead_Click);
            // 
            // btnStopRead
            // 
            this.btnStopRead.Location = new System.Drawing.Point(361, 175);
            this.btnStopRead.Name = "btnStopRead";
            this.btnStopRead.Size = new System.Drawing.Size(126, 29);
            this.btnStopRead.TabIndex = 27;
            this.btnStopRead.Text = "停止";
            this.btnStopRead.Click += new System.EventHandler(this.btnStopRead_Click);
            // 
            // txtSet
            // 
            this.txtSet.Location = new System.Drawing.Point(153, 272);
            this.txtSet.Name = "txtSet";
            this.txtSet.Size = new System.Drawing.Size(110, 23);
            this.txtSet.TabIndex = 30;
            this.txtSet.Text = "0";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(280, 271);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(64, 23);
            this.button1.TabIndex = 31;
            this.button1.Text = "设定";
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(798, 455);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtSet);
            this.Controls.Add(this.btnStopRead);
            this.Controls.Add(this.btnRead);
            this.Controls.Add(this.Label6);
            this.Controls.Add(this.lbliData);
            this.Controls.Add(this.txtbData4);
            this.Controls.Add(this.txtbData3);
            this.Controls.Add(this.txtbData2);
            this.Controls.Add(this.txtbData1);
            this.Controls.Add(this.txtbData0);
            this.Controls.Add(this.txtIData4);
            this.Controls.Add(this.txtIData3);
            this.Controls.Add(this.txtIData2);
            this.Controls.Add(this.txtIData1);
            this.Controls.Add(this.txtIData0);
            this.Menu = this.mainMenu1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Label lbliData;
        internal System.Windows.Forms.TextBox txtbData4;
        internal System.Windows.Forms.TextBox txtbData3;
        internal System.Windows.Forms.TextBox txtbData2;
        internal System.Windows.Forms.TextBox txtbData1;
        internal System.Windows.Forms.TextBox txtbData0;
        internal System.Windows.Forms.TextBox txtIData4;
        internal System.Windows.Forms.TextBox txtIData3;
        internal System.Windows.Forms.TextBox txtIData2;
        internal System.Windows.Forms.TextBox txtIData1;
        internal System.Windows.Forms.TextBox txtIData0;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btnRead;
        private System.Windows.Forms.Button btnStopRead;
        private System.Windows.Forms.TextBox txtSet;
        private System.Windows.Forms.Button button1;
    }
}

