﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

using TwinCAT.Ads;

namespace Samples
{
    public partial class Form1 : Form
    {
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
       
        private TcAdsClient tcClient;
        private string tcNetID;
        //
        private int _notificationHandle = 0;
        private int[] hConnect;
        private AdsStream dataStream;
        private BinaryReader binRead;

        public Form1()
        {
            InitializeComponent();
            try
            {
                dataStream = new AdsStream(31);
                //Encoding is set to ASCII, to read strings
                binRead = new BinaryReader(dataStream, System.Text.Encoding.ASCII);


                tcNetID = "10.41.2.10.1.1";
                tcClient = new TcAdsClient();
               // tcClient.Connect(tcNetID, 801);
                tcClient.Connect( 801);
            }
            catch (Exception ex)
            {
                MessageBox.Show("ADS 写入错误，请确认地址与偏移量是否正确及PLC程序是否运行！");
                //tcClient.Dispose();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //按地址写变量
           try
           {
               tcClient.WriteAny(0xF021, 0x13, Boolean.Parse(I_Bool_W_A.Text));
               tcClient.WriteAny(0xF020, 0x3, byte.Parse(I_Byte_W_A.Text));
               tcClient.WriteAny(0xF020, 0x5, short.Parse(I_Short_W_A.Text));
               tcClient.WriteAny(0xF020, 0x18, int.Parse(I_Int_W_A.Text));
               tcClient.WriteAny(0xF020, 0x28, I_String_W_A.Text, new int[] { 80 });

           }
           catch (System.Exception ex)
           {
               MessageBox.Show("ADS 写入错误，请确认地址与偏移量是否正确及PLC程序是否运行！");
           }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //按地址读变量
            try
            {
                I_Bool_R_A.Text = tcClient.ReadAny(0xF021, 0x13, typeof(bool)).ToString();
                I_Byte_R_A.Text = tcClient.ReadAny(0xF020, 0x3, typeof(byte)).ToString();
                I_Short_R_A.Text = tcClient.ReadAny(0xF020, 0x5, typeof(short)).ToString();
                I_Int_R_A.Text = tcClient.ReadAny(0xF020, 0x18, typeof(int)).ToString();
                object ob = tcClient.ReadAny(0xF020, 0x28, typeof(string), new int[] { 80 });
               I_String_R_A.Text = ob.ToString();

            }
            catch (System.Exception ex)
            {
                MessageBox.Show("ADS 读入错误，请确认地址与偏移量是否正确及PLC程序是否运行！");
            }
        }

        private void Form1_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            try
            {
                for (int i = 0; i < 5; i++)
                {
                    tcClient.DeleteDeviceNotification(hConnect[i]);
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
            tcClient.Dispose();
        }

    }


}
