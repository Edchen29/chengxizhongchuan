﻿namespace Samples
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
       

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.I_Bool_W_A = new System.Windows.Forms.TextBox();
            this.I_Byte_W_A = new System.Windows.Forms.TextBox();
            this.I_Short_W_A = new System.Windows.Forms.TextBox();
            this.I_Int_W_A = new System.Windows.Forms.TextBox();
            this.I_String_W_A = new System.Windows.Forms.TextBox();
            this.Write_byAddress = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Read_byAddress = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.I_String_R_A = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.I_Int_R_A = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.I_Short_R_A = new System.Windows.Forms.TextBox();
            this.I_Bool_R_A = new System.Windows.Forms.TextBox();
            this.I_Byte_R_A = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "InputBool";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "InputByte";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "InpuInt";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(33, 130);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "InpuDInt";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(33, 156);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "InpuString";
            // 
            // I_Bool_W_A
            // 
            this.I_Bool_W_A.Location = new System.Drawing.Point(95, 50);
            this.I_Bool_W_A.Name = "I_Bool_W_A";
            this.I_Bool_W_A.Size = new System.Drawing.Size(120, 20);
            this.I_Bool_W_A.TabIndex = 8;
            this.I_Bool_W_A.Text = "True";
            // 
            // I_Byte_W_A
            // 
            this.I_Byte_W_A.Location = new System.Drawing.Point(96, 75);
            this.I_Byte_W_A.Name = "I_Byte_W_A";
            this.I_Byte_W_A.Size = new System.Drawing.Size(120, 20);
            this.I_Byte_W_A.TabIndex = 9;
            this.I_Byte_W_A.Text = "11";
            // 
            // I_Short_W_A
            // 
            this.I_Short_W_A.Location = new System.Drawing.Point(95, 101);
            this.I_Short_W_A.Name = "I_Short_W_A";
            this.I_Short_W_A.Size = new System.Drawing.Size(120, 20);
            this.I_Short_W_A.TabIndex = 10;
            this.I_Short_W_A.Text = "45";
            // 
            // I_Int_W_A
            // 
            this.I_Int_W_A.Location = new System.Drawing.Point(95, 130);
            this.I_Int_W_A.Name = "I_Int_W_A";
            this.I_Int_W_A.Size = new System.Drawing.Size(120, 20);
            this.I_Int_W_A.TabIndex = 11;
            this.I_Int_W_A.Text = "123456";
            // 
            // I_String_W_A
            // 
            this.I_String_W_A.Location = new System.Drawing.Point(95, 156);
            this.I_String_W_A.Name = "I_String_W_A";
            this.I_String_W_A.Size = new System.Drawing.Size(120, 20);
            this.I_String_W_A.TabIndex = 12;
            this.I_String_W_A.Text = "beckhoff";
            // 
            // Write_byAddress
            // 
            this.Write_byAddress.Location = new System.Drawing.Point(232, 93);
            this.Write_byAddress.Name = "Write_byAddress";
            this.Write_byAddress.Size = new System.Drawing.Size(95, 34);
            this.Write_byAddress.TabIndex = 14;
            this.Write_byAddress.Text = "Write_byAddress";
            this.Write_byAddress.UseVisualStyleBackColor = true;
            this.Write_byAddress.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(20, 30);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(325, 160);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "写变量";
            // 
            // groupBox2
            // 
            this.groupBox2.Location = new System.Drawing.Point(20, 196);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(325, 160);
            this.groupBox2.TabIndex = 16;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "读变量";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(29, 225);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "InputBool";
            // 
            // Read_byAddress
            // 
            this.Read_byAddress.Location = new System.Drawing.Point(228, 260);
            this.Read_byAddress.Name = "Read_byAddress";
            this.Read_byAddress.Size = new System.Drawing.Size(99, 34);
            this.Read_byAddress.TabIndex = 14;
            this.Read_byAddress.Text = "Read_byAddress";
            this.Read_byAddress.UseVisualStyleBackColor = true;
            this.Read_byAddress.Click += new System.EventHandler(this.button2_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(29, 251);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "InputByte";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(29, 277);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "InpuInt";
            // 
            // I_String_R_A
            // 
            this.I_String_R_A.Location = new System.Drawing.Point(91, 329);
            this.I_String_R_A.Name = "I_String_R_A";
            this.I_String_R_A.Size = new System.Drawing.Size(120, 20);
            this.I_String_R_A.TabIndex = 12;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(29, 303);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "InpuDInt";
            // 
            // I_Int_R_A
            // 
            this.I_Int_R_A.Location = new System.Drawing.Point(91, 303);
            this.I_Int_R_A.Name = "I_Int_R_A";
            this.I_Int_R_A.Size = new System.Drawing.Size(120, 20);
            this.I_Int_R_A.TabIndex = 11;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(29, 329);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 13);
            this.label10.TabIndex = 4;
            this.label10.Text = "InpuString";
            // 
            // I_Short_R_A
            // 
            this.I_Short_R_A.Location = new System.Drawing.Point(91, 274);
            this.I_Short_R_A.Name = "I_Short_R_A";
            this.I_Short_R_A.Size = new System.Drawing.Size(120, 20);
            this.I_Short_R_A.TabIndex = 10;
            // 
            // I_Bool_R_A
            // 
            this.I_Bool_R_A.Location = new System.Drawing.Point(91, 223);
            this.I_Bool_R_A.Name = "I_Bool_R_A";
            this.I_Bool_R_A.Size = new System.Drawing.Size(120, 20);
            this.I_Bool_R_A.TabIndex = 8;
            // 
            // I_Byte_R_A
            // 
            this.I_Byte_R_A.Location = new System.Drawing.Point(91, 251);
            this.I_Byte_R_A.Name = "I_Byte_R_A";
            this.I_Byte_R_A.Size = new System.Drawing.Size(120, 20);
            this.I_Byte_R_A.TabIndex = 9;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.Read_byAddress);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.Write_byAddress);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.I_Byte_W_A);
            this.groupBox3.Controls.Add(this.I_String_R_A);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.I_Bool_W_A);
            this.groupBox3.Controls.Add(this.I_Int_R_A);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.I_Short_W_A);
            this.groupBox3.Controls.Add(this.I_Short_R_A);
            this.groupBox3.Controls.Add(this.I_String_W_A);
            this.groupBox3.Controls.Add(this.I_Bool_R_A);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.I_Byte_R_A);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.I_Int_W_A);
            this.groupBox3.Controls.Add(this.groupBox1);
            this.groupBox3.Controls.Add(this.groupBox2);
            this.groupBox3.Location = new System.Drawing.Point(12, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(351, 364);
            this.groupBox3.TabIndex = 17;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "按地址读写";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(378, 385);
            this.Controls.Add(this.groupBox3);
            this.Name = "Form1";
            this.Text = "按地址读写PLC变量";
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox I_Bool_W_A;
        private System.Windows.Forms.TextBox I_Byte_W_A;
        private System.Windows.Forms.TextBox I_Short_W_A;
        private System.Windows.Forms.TextBox I_Int_W_A;
        private System.Windows.Forms.TextBox I_String_W_A;
        private System.Windows.Forms.Button Write_byAddress;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button Read_byAddress;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox I_String_R_A;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox I_Int_R_A;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox I_Short_R_A;
        private System.Windows.Forms.TextBox I_Bool_R_A;
        private System.Windows.Forms.TextBox I_Byte_R_A;
        private System.Windows.Forms.GroupBox groupBox3;
    }
}

