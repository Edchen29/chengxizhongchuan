﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

using TwinCAT.Ads;

namespace Samples
{
    public partial class Form1 : Form
    {
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
       
        private TcAdsClient tcClient;
        private string tcNetID;
        //
        private int _notificationHandle = 0;
        private int[] hConnect;
        private AdsStream dataStream;
        private BinaryReader binRead;

        public Form1()
        {
            InitializeComponent();
            try
            {
                dataStream = new AdsStream(31);
                //Encoding is set to ASCII, to read strings
                binRead = new BinaryReader(dataStream, System.Text.Encoding.ASCII);


                tcNetID = "10.41.2.10.1.1";
                tcClient = new TcAdsClient();
               // tcClient.Connect(tcNetID, 801);
                tcClient.Connect(801);
            }
            catch (Exception ex)
            {
                MessageBox.Show("ADS 写入错误，请确认地址与偏移量是否正确及PLC程序是否运行！");
                //tcClient.Dispose();
            }
        }
                 
        private void Write_byName_Click(object sender, EventArgs e)
        {
            //按变量名写变量
            try
            {
                int hBool = tcClient.CreateVariableHandle("MAIN.InputBool");
                int hByte = tcClient.CreateVariableHandle("MAIN.InputByte");
                int hShort = tcClient.CreateVariableHandle("MAIN.InpuInt");
                int hInt = tcClient.CreateVariableHandle("MAIN.InpuDInt");
                int hString = tcClient.CreateVariableHandle("MAIN.InpuString");

                tcClient.WriteAny(hBool,Boolean.Parse(I_Bool_W_N.Text));
                tcClient.WriteAny(hByte, byte.Parse(I_Byte_W_N.Text));
                tcClient.WriteAny(hShort, short.Parse(I_Short_W_N.Text));
                tcClient.WriteAny(hInt, int.Parse(I_Int_W_N.Text));
                tcClient.WriteAny(hString, I_String_W_N.Text, new int[] { 80 });

                tcClient.DeleteVariableHandle(hBool);
                tcClient.DeleteVariableHandle(hByte);
                tcClient.DeleteVariableHandle(hShort);
                tcClient.DeleteVariableHandle(hInt);
                tcClient.DeleteVariableHandle(hString);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("ADS 写入错误，请确认地址与偏移量是否正确及PLC程序是否运行！");
            }

        }

        private void Read_byName_Click(object sender, EventArgs e)
        {
            //按变量名读地址
            try
            {
                int hBool = tcClient.CreateVariableHandle("MAIN.InputBool");
                int hByte = tcClient.CreateVariableHandle("MAIN.InputByte");
                int hShort = tcClient.CreateVariableHandle("MAIN.InpuInt");
                int hInt = tcClient.CreateVariableHandle("MAIN.InpuDInt");
                int hString = tcClient.CreateVariableHandle("MAIN.InpuString");

                I_Bool_R_N.Text = tcClient.ReadAny(hBool, typeof(bool)).ToString();
                I_Byte_R_N.Text = tcClient.ReadAny(hByte, typeof(byte)).ToString();
                I_Short_R_N.Text = tcClient.ReadAny(hShort, typeof(short)).ToString();
                I_Int_R_N.Text = tcClient.ReadAny(hInt, typeof(int)).ToString();
                object ob = tcClient.ReadAny(hString, typeof(string), new int[] { 80 });
                I_String_R_N.Text = ob.ToString();

                tcClient.DeleteVariableHandle(hBool);
                tcClient.DeleteVariableHandle(hByte);
                tcClient.DeleteVariableHandle(hShort);
                tcClient.DeleteVariableHandle(hInt);
                tcClient.DeleteVariableHandle(hString);

            }
            catch (System.Exception ex)
            {
                MessageBox.Show("ADS 读入错误，请确认地址与偏移量是否正确及PLC程序是否运行！");
            }
        }
      
        
        private void Form1_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            try
            {
                for (int i = 0; i < 5; i++)
                {
                    tcClient.DeleteDeviceNotification(hConnect[i]);
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
            tcClient.Dispose();
        }

    }


}
