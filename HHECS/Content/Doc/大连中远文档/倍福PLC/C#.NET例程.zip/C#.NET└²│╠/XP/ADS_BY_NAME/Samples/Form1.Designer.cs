﻿namespace Samples
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
       

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.Read_byName = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.Write_byName = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.I_Byte_W_N = new System.Windows.Forms.TextBox();
            this.I_String_R_N = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.I_Bool_W_N = new System.Windows.Forms.TextBox();
            this.I_Int_R_N = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.I_Short_W_N = new System.Windows.Forms.TextBox();
            this.I_Short_R_N = new System.Windows.Forms.TextBox();
            this.I_String_W_N = new System.Windows.Forms.TextBox();
            this.I_Bool_R_N = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.I_Byte_R_N = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.I_Int_W_N = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.Read_byName);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.Write_byName);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.I_Byte_W_N);
            this.groupBox4.Controls.Add(this.I_String_R_N);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.I_Bool_W_N);
            this.groupBox4.Controls.Add(this.I_Int_R_N);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.I_Short_W_N);
            this.groupBox4.Controls.Add(this.I_Short_R_N);
            this.groupBox4.Controls.Add(this.I_String_W_N);
            this.groupBox4.Controls.Add(this.I_Bool_R_N);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.I_Byte_R_N);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.I_Int_W_N);
            this.groupBox4.Controls.Add(this.groupBox5);
            this.groupBox4.Controls.Add(this.groupBox6);
            this.groupBox4.Location = new System.Drawing.Point(12, 12);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(351, 364);
            this.groupBox4.TabIndex = 18;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "按变量名读写";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(29, 225);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(52, 13);
            this.label11.TabIndex = 0;
            this.label11.Text = "InputBool";
            // 
            // Read_byName
            // 
            this.Read_byName.Location = new System.Drawing.Point(228, 260);
            this.Read_byName.Name = "Read_byName";
            this.Read_byName.Size = new System.Drawing.Size(95, 34);
            this.Read_byName.TabIndex = 14;
            this.Read_byName.Text = "Read_byName";
            this.Read_byName.UseVisualStyleBackColor = true;
            this.Read_byName.Click += new System.EventHandler(this.Read_byName_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(33, 52);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(52, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "InputBool";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(29, 251);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(52, 13);
            this.label13.TabIndex = 1;
            this.label13.Text = "InputByte";
            // 
            // Write_byName
            // 
            this.Write_byName.Location = new System.Drawing.Point(232, 93);
            this.Write_byName.Name = "Write_byName";
            this.Write_byName.Size = new System.Drawing.Size(95, 34);
            this.Write_byName.TabIndex = 14;
            this.Write_byName.Text = "Write_byName";
            this.Write_byName.UseVisualStyleBackColor = true;
            this.Write_byName.Click += new System.EventHandler(this.Write_byName_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(29, 277);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(40, 13);
            this.label14.TabIndex = 2;
            this.label14.Text = "InpuInt";
            // 
            // I_Byte_W_N
            // 
            this.I_Byte_W_N.Location = new System.Drawing.Point(96, 75);
            this.I_Byte_W_N.Name = "I_Byte_W_N";
            this.I_Byte_W_N.Size = new System.Drawing.Size(120, 20);
            this.I_Byte_W_N.TabIndex = 9;
            this.I_Byte_W_N.Text = "11";
            // 
            // I_String_R_N
            // 
            this.I_String_R_N.Location = new System.Drawing.Point(91, 329);
            this.I_String_R_N.Name = "I_String_R_N";
            this.I_String_R_N.Size = new System.Drawing.Size(120, 20);
            this.I_String_R_N.TabIndex = 12;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(33, 78);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(52, 13);
            this.label15.TabIndex = 1;
            this.label15.Text = "InputByte";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(29, 303);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(48, 13);
            this.label16.TabIndex = 3;
            this.label16.Text = "InpuDInt";
            // 
            // I_Bool_W_N
            // 
            this.I_Bool_W_N.Location = new System.Drawing.Point(95, 50);
            this.I_Bool_W_N.Name = "I_Bool_W_N";
            this.I_Bool_W_N.Size = new System.Drawing.Size(120, 20);
            this.I_Bool_W_N.TabIndex = 8;
            this.I_Bool_W_N.Text = "True";
            // 
            // I_Int_R_N
            // 
            this.I_Int_R_N.Location = new System.Drawing.Point(91, 303);
            this.I_Int_R_N.Name = "I_Int_R_N";
            this.I_Int_R_N.Size = new System.Drawing.Size(120, 20);
            this.I_Int_R_N.TabIndex = 11;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(33, 104);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(40, 13);
            this.label17.TabIndex = 2;
            this.label17.Text = "InpuInt";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(29, 329);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(55, 13);
            this.label18.TabIndex = 4;
            this.label18.Text = "InpuString";
            // 
            // I_Short_W_N
            // 
            this.I_Short_W_N.Location = new System.Drawing.Point(95, 101);
            this.I_Short_W_N.Name = "I_Short_W_N";
            this.I_Short_W_N.Size = new System.Drawing.Size(120, 20);
            this.I_Short_W_N.TabIndex = 10;
            this.I_Short_W_N.Text = "45";
            // 
            // I_Short_R_N
            // 
            this.I_Short_R_N.Location = new System.Drawing.Point(91, 274);
            this.I_Short_R_N.Name = "I_Short_R_N";
            this.I_Short_R_N.Size = new System.Drawing.Size(120, 20);
            this.I_Short_R_N.TabIndex = 10;
            // 
            // I_String_W_N
            // 
            this.I_String_W_N.Location = new System.Drawing.Point(95, 156);
            this.I_String_W_N.Name = "I_String_W_N";
            this.I_String_W_N.Size = new System.Drawing.Size(120, 20);
            this.I_String_W_N.TabIndex = 12;
            this.I_String_W_N.Text = "beckhoff";
            // 
            // I_Bool_R_N
            // 
            this.I_Bool_R_N.Location = new System.Drawing.Point(91, 223);
            this.I_Bool_R_N.Name = "I_Bool_R_N";
            this.I_Bool_R_N.Size = new System.Drawing.Size(120, 20);
            this.I_Bool_R_N.TabIndex = 8;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(33, 156);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(55, 13);
            this.label19.TabIndex = 4;
            this.label19.Text = "InpuString";
            // 
            // I_Byte_R_N
            // 
            this.I_Byte_R_N.Location = new System.Drawing.Point(91, 251);
            this.I_Byte_R_N.Name = "I_Byte_R_N";
            this.I_Byte_R_N.Size = new System.Drawing.Size(120, 20);
            this.I_Byte_R_N.TabIndex = 9;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(33, 130);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(48, 13);
            this.label20.TabIndex = 3;
            this.label20.Text = "InpuDInt";
            // 
            // I_Int_W_N
            // 
            this.I_Int_W_N.Location = new System.Drawing.Point(95, 130);
            this.I_Int_W_N.Name = "I_Int_W_N";
            this.I_Int_W_N.Size = new System.Drawing.Size(120, 20);
            this.I_Int_W_N.TabIndex = 11;
            this.I_Int_W_N.Text = "123456";
            // 
            // groupBox5
            // 
            this.groupBox5.Location = new System.Drawing.Point(20, 30);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(325, 160);
            this.groupBox5.TabIndex = 15;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "写变量";
            // 
            // groupBox6
            // 
            this.groupBox6.Location = new System.Drawing.Point(20, 196);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(325, 160);
            this.groupBox6.TabIndex = 16;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "读变量";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(375, 381);
            this.Controls.Add(this.groupBox4);
            this.Name = "Form1";
            this.Text = "按地址读写PLC变量";
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button Read_byName;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button Write_byName;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox I_Byte_W_N;
        private System.Windows.Forms.TextBox I_String_R_N;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox I_Bool_W_N;
        private System.Windows.Forms.TextBox I_Int_R_N;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox I_Short_W_N;
        private System.Windows.Forms.TextBox I_Short_R_N;
        private System.Windows.Forms.TextBox I_String_W_N;
        private System.Windows.Forms.TextBox I_Bool_R_N;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox I_Byte_R_N;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox I_Int_W_N;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
    }
}

