﻿namespace HUAHENG.Project.Ads
{
    partial class FrmCutting_BevelingPCstation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tBox_RawPipeLength = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tBox_Finished4 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Btn_Send = new System.Windows.Forms.Button();
            this.tBox_Pipe10 = new System.Windows.Forms.TextBox();
            this.tBox_Pipe9 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.tBox_Pipe8 = new System.Windows.Forms.TextBox();
            this.tBox_Pipe7 = new System.Windows.Forms.TextBox();
            this.tBox_Pipe6 = new System.Windows.Forms.TextBox();
            this.tBox_Pipe5 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.comBox_BevelType = new System.Windows.Forms.ComboBox();
            this.comBox_Beveled = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tBox_BevelAngle = new System.Windows.Forms.TextBox();
            this.tBox_Pipe4 = new System.Windows.Forms.TextBox();
            this.tBox_Pipe3 = new System.Windows.Forms.TextBox();
            this.tBox_Pipe2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tBox_Pipe1 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.tBox_MaterialType = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tBox_PipeCount = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.tBox_OD = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tBox_WT = new System.Windows.Forms.TextBox();
            this.tBox_Finished3 = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Btn_Read = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.tBox_Finished9 = new System.Windows.Forms.TextBox();
            this.tBox_Finished10 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.tBox_Finished8 = new System.Windows.Forms.TextBox();
            this.tBox_Finished5 = new System.Windows.Forms.TextBox();
            this.tBox_Finished7 = new System.Windows.Forms.TextBox();
            this.tBox_Finished6 = new System.Windows.Forms.TextBox();
            this.tBox_Finished1 = new System.Windows.Forms.TextBox();
            this.tBox_Finished2 = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tBox_RawPipeLength
            // 
            this.tBox_RawPipeLength.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_RawPipeLength.Location = new System.Drawing.Point(129, 26);
            this.tBox_RawPipeLength.Name = "tBox_RawPipeLength";
            this.tBox_RawPipeLength.Size = new System.Drawing.Size(142, 20);
            this.tBox_RawPipeLength.TabIndex = 21;
            this.tBox_RawPipeLength.Text = "100";
            this.tBox_RawPipeLength.TextChanged += new System.EventHandler(this.TBox_RawPipeLength_TextChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(6, 79);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(55, 13);
            this.label12.TabIndex = 11;
            this.label12.Text = "Finished3:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(6, 51);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(55, 13);
            this.label11.TabIndex = 8;
            this.label11.Text = "Finished2:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(92, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "OD:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(6, 21);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Finished1:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(87, 107);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "WT:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(6, 106);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(55, 13);
            this.label13.TabIndex = 10;
            this.label13.Text = "Finished4:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(44, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "MaterialType:";
            // 
            // tBox_Finished4
            // 
            this.tBox_Finished4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_Finished4.Location = new System.Drawing.Point(77, 103);
            this.tBox_Finished4.Name = "tBox_Finished4";
            this.tBox_Finished4.Size = new System.Drawing.Size(142, 20);
            this.tBox_Finished4.TabIndex = 25;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Btn_Send);
            this.groupBox1.Controls.Add(this.tBox_Pipe10);
            this.groupBox1.Controls.Add(this.tBox_Pipe9);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.tBox_Pipe8);
            this.groupBox1.Controls.Add(this.tBox_Pipe7);
            this.groupBox1.Controls.Add(this.tBox_Pipe6);
            this.groupBox1.Controls.Add(this.tBox_Pipe5);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.comBox_BevelType);
            this.groupBox1.Controls.Add(this.comBox_Beveled);
            this.groupBox1.Controls.Add(this.tBox_RawPipeLength);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.tBox_BevelAngle);
            this.groupBox1.Controls.Add(this.tBox_Pipe4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.tBox_Pipe3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.tBox_Pipe2);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.tBox_Pipe1);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.tBox_MaterialType);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.tBox_PipeCount);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.tBox_OD);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.tBox_WT);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 11);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(278, 586);
            this.groupBox1.TabIndex = 34;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Write to Control";
            // 
            // Btn_Send
            // 
            this.Btn_Send.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Send.Location = new System.Drawing.Point(124, 545);
            this.Btn_Send.Name = "Btn_Send";
            this.Btn_Send.Size = new System.Drawing.Size(146, 23);
            this.Btn_Send.TabIndex = 38;
            this.Btn_Send.Text = "Send";
            this.Btn_Send.UseVisualStyleBackColor = true;
            this.Btn_Send.Click += new System.EventHandler(this.Btn_Send_Click);
            // 
            // tBox_Pipe10
            // 
            this.tBox_Pipe10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_Pipe10.Location = new System.Drawing.Point(128, 394);
            this.tBox_Pipe10.Name = "tBox_Pipe10";
            this.tBox_Pipe10.Size = new System.Drawing.Size(142, 20);
            this.tBox_Pipe10.TabIndex = 37;
            this.tBox_Pipe10.Text = "0";
            // 
            // tBox_Pipe9
            // 
            this.tBox_Pipe9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_Pipe9.Location = new System.Drawing.Point(128, 367);
            this.tBox_Pipe9.Name = "tBox_Pipe9";
            this.tBox_Pipe9.Size = new System.Drawing.Size(142, 20);
            this.tBox_Pipe9.TabIndex = 36;
            this.tBox_Pipe9.Text = "0";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(85, 398);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(43, 13);
            this.label21.TabIndex = 35;
            this.label21.Text = "Pipe10:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(85, 370);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(37, 13);
            this.label22.TabIndex = 34;
            this.label22.Text = "Pipe9:";
            // 
            // tBox_Pipe8
            // 
            this.tBox_Pipe8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_Pipe8.Location = new System.Drawing.Point(129, 344);
            this.tBox_Pipe8.Name = "tBox_Pipe8";
            this.tBox_Pipe8.Size = new System.Drawing.Size(142, 20);
            this.tBox_Pipe8.TabIndex = 32;
            this.tBox_Pipe8.Text = "0";
            // 
            // tBox_Pipe7
            // 
            this.tBox_Pipe7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_Pipe7.Location = new System.Drawing.Point(129, 317);
            this.tBox_Pipe7.Name = "tBox_Pipe7";
            this.tBox_Pipe7.Size = new System.Drawing.Size(142, 20);
            this.tBox_Pipe7.TabIndex = 31;
            this.tBox_Pipe7.Text = "0";
            // 
            // tBox_Pipe6
            // 
            this.tBox_Pipe6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_Pipe6.Location = new System.Drawing.Point(129, 290);
            this.tBox_Pipe6.Name = "tBox_Pipe6";
            this.tBox_Pipe6.Size = new System.Drawing.Size(142, 20);
            this.tBox_Pipe6.TabIndex = 33;
            this.tBox_Pipe6.Text = "0";
            // 
            // tBox_Pipe5
            // 
            this.tBox_Pipe5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_Pipe5.Location = new System.Drawing.Point(129, 263);
            this.tBox_Pipe5.Name = "tBox_Pipe5";
            this.tBox_Pipe5.Size = new System.Drawing.Size(142, 20);
            this.tBox_Pipe5.TabIndex = 30;
            this.tBox_Pipe5.Text = "0";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(86, 348);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(37, 13);
            this.label17.TabIndex = 29;
            this.label17.Text = "Pipe8:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(86, 267);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(37, 13);
            this.label18.TabIndex = 26;
            this.label18.Text = "Pipe5:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(86, 320);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(37, 13);
            this.label19.TabIndex = 28;
            this.label19.Text = "Pipe7:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(86, 293);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(37, 13);
            this.label20.TabIndex = 27;
            this.label20.Text = "Pipe6:";
            // 
            // comBox_BevelType
            // 
            this.comBox_BevelType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comBox_BevelType.FormattingEnabled = true;
            this.comBox_BevelType.Items.AddRange(new object[] {
            "V",
            "VV",
            "U"});
            this.comBox_BevelType.Location = new System.Drawing.Point(128, 463);
            this.comBox_BevelType.Name = "comBox_BevelType";
            this.comBox_BevelType.Size = new System.Drawing.Size(141, 21);
            this.comBox_BevelType.TabIndex = 25;
            // 
            // comBox_Beveled
            // 
            this.comBox_Beveled.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comBox_Beveled.FormattingEnabled = true;
            this.comBox_Beveled.Items.AddRange(new object[] {
            "Y",
            "N"});
            this.comBox_Beveled.Location = new System.Drawing.Point(129, 429);
            this.comBox_Beveled.Name = "comBox_Beveled";
            this.comBox_Beveled.Size = new System.Drawing.Size(141, 21);
            this.comBox_Beveled.TabIndex = 25;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(38, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "RawPipeLength:";
            // 
            // tBox_BevelAngle
            // 
            this.tBox_BevelAngle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_BevelAngle.Location = new System.Drawing.Point(128, 489);
            this.tBox_BevelAngle.Name = "tBox_BevelAngle";
            this.tBox_BevelAngle.Size = new System.Drawing.Size(142, 20);
            this.tBox_BevelAngle.TabIndex = 19;
            this.tBox_BevelAngle.Text = "25.22";
            // 
            // tBox_Pipe4
            // 
            this.tBox_Pipe4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_Pipe4.Location = new System.Drawing.Point(129, 239);
            this.tBox_Pipe4.Name = "tBox_Pipe4";
            this.tBox_Pipe4.Size = new System.Drawing.Size(142, 20);
            this.tBox_Pipe4.TabIndex = 19;
            this.tBox_Pipe4.Text = "0";
            // 
            // tBox_Pipe3
            // 
            this.tBox_Pipe3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_Pipe3.Location = new System.Drawing.Point(129, 212);
            this.tBox_Pipe3.Name = "tBox_Pipe3";
            this.tBox_Pipe3.Size = new System.Drawing.Size(142, 20);
            this.tBox_Pipe3.TabIndex = 18;
            this.tBox_Pipe3.Text = "1700";
            // 
            // tBox_Pipe2
            // 
            this.tBox_Pipe2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_Pipe2.Location = new System.Drawing.Point(129, 185);
            this.tBox_Pipe2.Name = "tBox_Pipe2";
            this.tBox_Pipe2.Size = new System.Drawing.Size(142, 20);
            this.tBox_Pipe2.TabIndex = 20;
            this.tBox_Pipe2.Text = "1600";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(62, 135);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "PipeCount:";
            // 
            // tBox_Pipe1
            // 
            this.tBox_Pipe1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_Pipe1.Location = new System.Drawing.Point(129, 158);
            this.tBox_Pipe1.Name = "tBox_Pipe1";
            this.tBox_Pipe1.Size = new System.Drawing.Size(142, 20);
            this.tBox_Pipe1.TabIndex = 16;
            this.tBox_Pipe1.Text = "1500";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(1, 492);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(101, 13);
            this.label16.TabIndex = 14;
            this.label16.Text = "BeleveAngle(0-90°):";
            // 
            // tBox_MaterialType
            // 
            this.tBox_MaterialType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_MaterialType.Location = new System.Drawing.Point(129, 53);
            this.tBox_MaterialType.Name = "tBox_MaterialType";
            this.tBox_MaterialType.Size = new System.Drawing.Size(142, 20);
            this.tBox_MaterialType.TabIndex = 22;
            this.tBox_MaterialType.Text = "sss";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(86, 243);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(37, 13);
            this.label9.TabIndex = 14;
            this.label9.Text = "Pipe4:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(86, 161);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Pipe1:";
            // 
            // tBox_PipeCount
            // 
            this.tBox_PipeCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_PipeCount.Location = new System.Drawing.Point(129, 131);
            this.tBox_PipeCount.Name = "tBox_PipeCount";
            this.tBox_PipeCount.Size = new System.Drawing.Size(142, 20);
            this.tBox_PipeCount.TabIndex = 17;
            this.tBox_PipeCount.Text = "3";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(55, 466);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(67, 13);
            this.label15.TabIndex = 13;
            this.label15.Text = "BeleveType:";
            // 
            // tBox_OD
            // 
            this.tBox_OD.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_OD.Location = new System.Drawing.Point(129, 75);
            this.tBox_OD.Name = "tBox_OD";
            this.tBox_OD.Size = new System.Drawing.Size(142, 20);
            this.tBox_OD.TabIndex = 24;
            this.tBox_OD.Text = "3.124";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(49, 439);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(69, 13);
            this.label14.TabIndex = 12;
            this.label14.Text = "Beleve(Y/N):";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(86, 215);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "Pipe3:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(86, 188);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Pipe2:";
            // 
            // tBox_WT
            // 
            this.tBox_WT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_WT.Location = new System.Drawing.Point(129, 104);
            this.tBox_WT.Name = "tBox_WT";
            this.tBox_WT.Size = new System.Drawing.Size(142, 20);
            this.tBox_WT.TabIndex = 23;
            this.tBox_WT.Text = "2.155";
            // 
            // tBox_Finished3
            // 
            this.tBox_Finished3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_Finished3.Location = new System.Drawing.Point(77, 76);
            this.tBox_Finished3.Name = "tBox_Finished3";
            this.tBox_Finished3.Size = new System.Drawing.Size(142, 20);
            this.tBox_Finished3.TabIndex = 28;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Btn_Read);
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.tBox_Finished9);
            this.groupBox2.Controls.Add(this.tBox_Finished10);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.tBox_Finished8);
            this.groupBox2.Controls.Add(this.tBox_Finished5);
            this.groupBox2.Controls.Add(this.tBox_Finished7);
            this.groupBox2.Controls.Add(this.tBox_Finished6);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.tBox_Finished4);
            this.groupBox2.Controls.Add(this.tBox_Finished1);
            this.groupBox2.Controls.Add(this.tBox_Finished3);
            this.groupBox2.Controls.Add(this.tBox_Finished2);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(308, 11);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(259, 360);
            this.groupBox2.TabIndex = 35;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Read from Control";
            // 
            // Btn_Read
            // 
            this.Btn_Read.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Read.Location = new System.Drawing.Point(82, 320);
            this.Btn_Read.Name = "Btn_Read";
            this.Btn_Read.Size = new System.Drawing.Size(137, 23);
            this.Btn_Read.TabIndex = 44;
            this.Btn_Read.Text = "Read";
            this.Btn_Read.UseVisualStyleBackColor = true;
            this.Btn_Read.Click += new System.EventHandler(this.Btn_Read_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(6, 245);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(55, 13);
            this.label27.TabIndex = 38;
            this.label27.Text = "Finished9:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(6, 275);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(61, 13);
            this.label28.TabIndex = 37;
            this.label28.Text = "Finished10:";
            // 
            // tBox_Finished9
            // 
            this.tBox_Finished9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_Finished9.Location = new System.Drawing.Point(77, 243);
            this.tBox_Finished9.Name = "tBox_Finished9";
            this.tBox_Finished9.Size = new System.Drawing.Size(142, 20);
            this.tBox_Finished9.TabIndex = 42;
            // 
            // tBox_Finished10
            // 
            this.tBox_Finished10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_Finished10.Location = new System.Drawing.Point(77, 272);
            this.tBox_Finished10.Name = "tBox_Finished10";
            this.tBox_Finished10.Size = new System.Drawing.Size(142, 20);
            this.tBox_Finished10.TabIndex = 43;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(6, 130);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(55, 13);
            this.label23.TabIndex = 30;
            this.label23.Text = "Finished5:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(6, 160);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(55, 13);
            this.label24.TabIndex = 29;
            this.label24.Text = "Finished6:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(6, 187);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(55, 13);
            this.label25.TabIndex = 32;
            this.label25.Text = "Finished7:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(6, 215);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(55, 13);
            this.label26.TabIndex = 31;
            this.label26.Text = "Finished8:";
            // 
            // tBox_Finished8
            // 
            this.tBox_Finished8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_Finished8.Location = new System.Drawing.Point(77, 212);
            this.tBox_Finished8.Name = "tBox_Finished8";
            this.tBox_Finished8.Size = new System.Drawing.Size(142, 20);
            this.tBox_Finished8.TabIndex = 33;
            // 
            // tBox_Finished5
            // 
            this.tBox_Finished5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_Finished5.Location = new System.Drawing.Point(77, 127);
            this.tBox_Finished5.Name = "tBox_Finished5";
            this.tBox_Finished5.Size = new System.Drawing.Size(142, 20);
            this.tBox_Finished5.TabIndex = 34;
            // 
            // tBox_Finished7
            // 
            this.tBox_Finished7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_Finished7.Location = new System.Drawing.Point(77, 185);
            this.tBox_Finished7.Name = "tBox_Finished7";
            this.tBox_Finished7.Size = new System.Drawing.Size(142, 20);
            this.tBox_Finished7.TabIndex = 36;
            // 
            // tBox_Finished6
            // 
            this.tBox_Finished6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_Finished6.Location = new System.Drawing.Point(77, 157);
            this.tBox_Finished6.Name = "tBox_Finished6";
            this.tBox_Finished6.Size = new System.Drawing.Size(142, 20);
            this.tBox_Finished6.TabIndex = 35;
            // 
            // tBox_Finished1
            // 
            this.tBox_Finished1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_Finished1.Location = new System.Drawing.Point(77, 19);
            this.tBox_Finished1.Name = "tBox_Finished1";
            this.tBox_Finished1.Size = new System.Drawing.Size(142, 20);
            this.tBox_Finished1.TabIndex = 26;
            this.tBox_Finished1.TextChanged += new System.EventHandler(this.TBox_Finished1_TextChanged);
            // 
            // tBox_Finished2
            // 
            this.tBox_Finished2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_Finished2.Location = new System.Drawing.Point(77, 48);
            this.tBox_Finished2.Name = "tBox_Finished2";
            this.tBox_Finished2.Size = new System.Drawing.Size(142, 20);
            this.tBox_Finished2.TabIndex = 27;
            // 
            // FrmCutting_BevelingPCstation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(595, 605);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Name = "FrmCutting_BevelingPCstation";
            this.Text = "Cutting Beveling PC station Simulation";
            this.Load += new System.EventHandler(this.FrmCutting_BevelingPCstation_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox tBox_RawPipeLength;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tBox_Finished4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox comBox_Beveled;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tBox_BevelAngle;
        private System.Windows.Forms.TextBox tBox_Pipe4;
        private System.Windows.Forms.TextBox tBox_Pipe3;
        private System.Windows.Forms.TextBox tBox_Pipe2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tBox_Pipe1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox tBox_MaterialType;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tBox_PipeCount;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tBox_OD;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tBox_WT;
        private System.Windows.Forms.TextBox tBox_Finished3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox tBox_Finished1;
        private System.Windows.Forms.TextBox tBox_Finished2;
        private System.Windows.Forms.ComboBox comBox_BevelType;
        private System.Windows.Forms.TextBox tBox_Pipe10;
        private System.Windows.Forms.TextBox tBox_Pipe9;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox tBox_Pipe8;
        private System.Windows.Forms.TextBox tBox_Pipe7;
        private System.Windows.Forms.TextBox tBox_Pipe6;
        private System.Windows.Forms.TextBox tBox_Pipe5;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button Btn_Send;
        private System.Windows.Forms.Button Btn_Read;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox tBox_Finished9;
        private System.Windows.Forms.TextBox tBox_Finished10;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox tBox_Finished8;
        private System.Windows.Forms.TextBox tBox_Finished5;
        private System.Windows.Forms.TextBox tBox_Finished7;
        private System.Windows.Forms.TextBox tBox_Finished6;
    }
}