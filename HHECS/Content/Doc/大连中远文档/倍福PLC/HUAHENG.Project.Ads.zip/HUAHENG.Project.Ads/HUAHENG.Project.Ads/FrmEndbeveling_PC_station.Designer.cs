﻿namespace HUAHENG.Project.Ads
{
    partial class FrmEndbeveling_PC_station
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comBox_BeleveType = new System.Windows.Forms.ComboBox();
            this.comBox_Beleve = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tBox_BeleveAngle = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.tBox_MaterialType = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.tBox_OD = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.tBox_WT = new System.Windows.Forms.TextBox();
            this.tBox_Finished = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.Btn_Read = new System.Windows.Forms.Button();
            this.Btn_Send = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.comBox_BeleveType);
            this.groupBox1.Controls.Add(this.comBox_Beleve);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.tBox_BeleveAngle);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.tBox_MaterialType);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.tBox_OD);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.tBox_WT);
            this.groupBox1.Location = new System.Drawing.Point(7, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(278, 268);
            this.groupBox1.TabIndex = 38;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Write to Control";
            // 
            // comBox_BeleveType
            // 
            this.comBox_BeleveType.FormattingEnabled = true;
            this.comBox_BeleveType.Items.AddRange(new object[] {
            "V",
            "VV",
            "U"});
            this.comBox_BeleveType.Location = new System.Drawing.Point(127, 142);
            this.comBox_BeleveType.Name = "comBox_BeleveType";
            this.comBox_BeleveType.Size = new System.Drawing.Size(141, 20);
            this.comBox_BeleveType.TabIndex = 25;
            // 
            // comBox_Beleve
            // 
            this.comBox_Beleve.FormattingEnabled = true;
            this.comBox_Beleve.Items.AddRange(new object[] {
            "Y",
            "N"});
            this.comBox_Beleve.Location = new System.Drawing.Point(128, 108);
            this.comBox_Beleve.Name = "comBox_Beleve";
            this.comBox_Beleve.Size = new System.Drawing.Size(141, 20);
            this.comBox_Beleve.TabIndex = 25;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(43, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 12);
            this.label2.TabIndex = 7;
            this.label2.Text = "MaterialType:";
            // 
            // tBox_BeleveAngle
            // 
            this.tBox_BeleveAngle.Location = new System.Drawing.Point(127, 168);
            this.tBox_BeleveAngle.Name = "tBox_BeleveAngle";
            this.tBox_BeleveAngle.Size = new System.Drawing.Size(142, 21);
            this.tBox_BeleveAngle.TabIndex = 19;
            this.tBox_BeleveAngle.Text = "25.22";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(103, 58);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 12);
            this.label3.TabIndex = 4;
            this.label3.Text = "OD:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(103, 87);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "WT:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(0, 171);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(125, 12);
            this.label16.TabIndex = 14;
            this.label16.Text = "BeleveAngle(0-90°):";
            // 
            // tBox_MaterialType
            // 
            this.tBox_MaterialType.Location = new System.Drawing.Point(128, 27);
            this.tBox_MaterialType.Name = "tBox_MaterialType";
            this.tBox_MaterialType.Size = new System.Drawing.Size(142, 21);
            this.tBox_MaterialType.TabIndex = 22;
            this.tBox_MaterialType.Text = "sss";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(54, 145);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(71, 12);
            this.label15.TabIndex = 13;
            this.label15.Text = "BeleveType:";
            // 
            // tBox_OD
            // 
            this.tBox_OD.Location = new System.Drawing.Point(128, 49);
            this.tBox_OD.Name = "tBox_OD";
            this.tBox_OD.Size = new System.Drawing.Size(142, 21);
            this.tBox_OD.TabIndex = 24;
            this.tBox_OD.Text = "3.124";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(48, 117);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(77, 12);
            this.label14.TabIndex = 12;
            this.label14.Text = "Beleve(Y/N):";
            // 
            // tBox_WT
            // 
            this.tBox_WT.Location = new System.Drawing.Point(128, 78);
            this.tBox_WT.Name = "tBox_WT";
            this.tBox_WT.Size = new System.Drawing.Size(142, 21);
            this.tBox_WT.TabIndex = 23;
            this.tBox_WT.Text = "2.155";
            // 
            // tBox_Finished
            // 
            this.tBox_Finished.Location = new System.Drawing.Point(77, 18);
            this.tBox_Finished.Name = "tBox_Finished";
            this.tBox_Finished.Size = new System.Drawing.Size(142, 21);
            this.tBox_Finished.TabIndex = 26;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.tBox_Finished);
            this.groupBox2.Location = new System.Drawing.Point(291, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(259, 179);
            this.groupBox2.TabIndex = 39;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Read from Control";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 27);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 12);
            this.label10.TabIndex = 9;
            this.label10.Text = "Finished:";
            // 
            // Btn_Read
            // 
            this.Btn_Read.Location = new System.Drawing.Point(435, 257);
            this.Btn_Read.Name = "Btn_Read";
            this.Btn_Read.Size = new System.Drawing.Size(75, 23);
            this.Btn_Read.TabIndex = 36;
            this.Btn_Read.Text = "Read";
            this.Btn_Read.UseVisualStyleBackColor = true;
            this.Btn_Read.Click += new System.EventHandler(this.Btn_Read_Click);
            // 
            // Btn_Send
            // 
            this.Btn_Send.Location = new System.Drawing.Point(334, 257);
            this.Btn_Send.Name = "Btn_Send";
            this.Btn_Send.Size = new System.Drawing.Size(75, 23);
            this.Btn_Send.TabIndex = 37;
            this.Btn_Send.Text = "Send";
            this.Btn_Send.UseVisualStyleBackColor = true;
            this.Btn_Send.Click += new System.EventHandler(this.Btn_Send_Click);
            // 
            // Endbeveling_PC_station
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(562, 301);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.Btn_Read);
            this.Controls.Add(this.Btn_Send);
            this.Name = "Endbeveling_PC_station";
            this.Text = "Endbeveling_PC_station";
            this.Load += new System.EventHandler(this.Endbeveling_PC_station_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox comBox_BeleveType;
        private System.Windows.Forms.ComboBox comBox_Beleve;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tBox_BeleveAngle;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox tBox_MaterialType;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tBox_OD;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox tBox_WT;
        private System.Windows.Forms.TextBox tBox_Finished;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button Btn_Read;
        private System.Windows.Forms.Button Btn_Send;
    }
}