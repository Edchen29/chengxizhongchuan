﻿namespace HUAHENG.Project.Ads
{
    partial class FrmCutting_PC_station
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn_Send = new System.Windows.Forms.Button();
            this.tBox_Pipe4 = new System.Windows.Forms.TextBox();
            this.tBox_Pipe3 = new System.Windows.Forms.TextBox();
            this.tBox_Pipe2 = new System.Windows.Forms.TextBox();
            this.tBox_Pipe1 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tBox_PipeCount = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tBox_WT = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tBox_OD = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tBox_MaterialType = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tBox_Finished4 = new System.Windows.Forms.TextBox();
            this.tBox_Finished3 = new System.Windows.Forms.TextBox();
            this.tBox_Finished2 = new System.Windows.Forms.TextBox();
            this.tBox_Finished1 = new System.Windows.Forms.TextBox();
            this.tBox_RawPipeLength = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Btn_Read = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Btn_Send
            // 
            this.Btn_Send.Location = new System.Drawing.Point(337, 262);
            this.Btn_Send.Name = "Btn_Send";
            this.Btn_Send.Size = new System.Drawing.Size(75, 23);
            this.Btn_Send.TabIndex = 29;
            this.Btn_Send.Text = "Send";
            this.Btn_Send.UseVisualStyleBackColor = true;
            this.Btn_Send.Click += new System.EventHandler(this.Btn_Send_Click);
            // 
            // tBox_Pipe4
            // 
            this.tBox_Pipe4.Location = new System.Drawing.Point(106, 239);
            this.tBox_Pipe4.Name = "tBox_Pipe4";
            this.tBox_Pipe4.Size = new System.Drawing.Size(142, 21);
            this.tBox_Pipe4.TabIndex = 19;
            this.tBox_Pipe4.Text = "25";
            // 
            // tBox_Pipe3
            // 
            this.tBox_Pipe3.Location = new System.Drawing.Point(106, 212);
            this.tBox_Pipe3.Name = "tBox_Pipe3";
            this.tBox_Pipe3.Size = new System.Drawing.Size(142, 21);
            this.tBox_Pipe3.TabIndex = 18;
            this.tBox_Pipe3.Text = "25";
            // 
            // tBox_Pipe2
            // 
            this.tBox_Pipe2.Location = new System.Drawing.Point(106, 185);
            this.tBox_Pipe2.Name = "tBox_Pipe2";
            this.tBox_Pipe2.Size = new System.Drawing.Size(142, 21);
            this.tBox_Pipe2.TabIndex = 20;
            this.tBox_Pipe2.Text = "25";
            // 
            // tBox_Pipe1
            // 
            this.tBox_Pipe1.Location = new System.Drawing.Point(106, 158);
            this.tBox_Pipe1.Name = "tBox_Pipe1";
            this.tBox_Pipe1.Size = new System.Drawing.Size(142, 21);
            this.tBox_Pipe1.TabIndex = 16;
            this.tBox_Pipe1.Text = "25";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(59, 248);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 12);
            this.label9.TabIndex = 14;
            this.label9.Text = "Pipe4:";
            // 
            // tBox_PipeCount
            // 
            this.tBox_PipeCount.Location = new System.Drawing.Point(106, 131);
            this.tBox_PipeCount.Name = "tBox_PipeCount";
            this.tBox_PipeCount.Size = new System.Drawing.Size(142, 21);
            this.tBox_PipeCount.TabIndex = 17;
            this.tBox_PipeCount.Text = "4";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(59, 221);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 12);
            this.label8.TabIndex = 13;
            this.label8.Text = "Pipe3:";
            // 
            // tBox_WT
            // 
            this.tBox_WT.Location = new System.Drawing.Point(106, 104);
            this.tBox_WT.Name = "tBox_WT";
            this.tBox_WT.Size = new System.Drawing.Size(142, 21);
            this.tBox_WT.TabIndex = 23;
            this.tBox_WT.Text = "2.155";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(59, 194);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 12);
            this.label7.TabIndex = 12;
            this.label7.Text = "Pipe2:";
            // 
            // tBox_OD
            // 
            this.tBox_OD.Location = new System.Drawing.Point(106, 75);
            this.tBox_OD.Name = "tBox_OD";
            this.tBox_OD.Size = new System.Drawing.Size(142, 21);
            this.tBox_OD.TabIndex = 24;
            this.tBox_OD.Text = "3.124";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(59, 167);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 12);
            this.label6.TabIndex = 5;
            this.label6.Text = "Pipe1:";
            // 
            // tBox_MaterialType
            // 
            this.tBox_MaterialType.Location = new System.Drawing.Point(106, 53);
            this.tBox_MaterialType.Name = "tBox_MaterialType";
            this.tBox_MaterialType.Size = new System.Drawing.Size(142, 21);
            this.tBox_MaterialType.TabIndex = 22;
            this.tBox_MaterialType.Text = "sss";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(35, 140);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 12);
            this.label5.TabIndex = 15;
            this.label5.Text = "PipeCount:";
            // 
            // tBox_Finished4
            // 
            this.tBox_Finished4.Location = new System.Drawing.Point(77, 103);
            this.tBox_Finished4.Name = "tBox_Finished4";
            this.tBox_Finished4.Size = new System.Drawing.Size(142, 21);
            this.tBox_Finished4.TabIndex = 25;
            // 
            // tBox_Finished3
            // 
            this.tBox_Finished3.Location = new System.Drawing.Point(77, 76);
            this.tBox_Finished3.Name = "tBox_Finished3";
            this.tBox_Finished3.Size = new System.Drawing.Size(142, 21);
            this.tBox_Finished3.TabIndex = 28;
            // 
            // tBox_Finished2
            // 
            this.tBox_Finished2.Location = new System.Drawing.Point(77, 48);
            this.tBox_Finished2.Name = "tBox_Finished2";
            this.tBox_Finished2.Size = new System.Drawing.Size(142, 21);
            this.tBox_Finished2.TabIndex = 27;
            // 
            // tBox_Finished1
            // 
            this.tBox_Finished1.Location = new System.Drawing.Point(77, 18);
            this.tBox_Finished1.Name = "tBox_Finished1";
            this.tBox_Finished1.Size = new System.Drawing.Size(142, 21);
            this.tBox_Finished1.TabIndex = 26;
            // 
            // tBox_RawPipeLength
            // 
            this.tBox_RawPipeLength.Location = new System.Drawing.Point(106, 26);
            this.tBox_RawPipeLength.Name = "tBox_RawPipeLength";
            this.tBox_RawPipeLength.Size = new System.Drawing.Size(142, 21);
            this.tBox_RawPipeLength.TabIndex = 21;
            this.tBox_RawPipeLength.Text = "100";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(77, 113);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "WT:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(77, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 12);
            this.label3.TabIndex = 4;
            this.label3.Text = "OD:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 12);
            this.label2.TabIndex = 7;
            this.label2.Text = "MaterialType:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 111);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 12);
            this.label13.TabIndex = 10;
            this.label13.Text = "Finished4:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 82);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 12);
            this.label12.TabIndex = 11;
            this.label12.Text = "Finished3:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 57);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 12);
            this.label11.TabIndex = 8;
            this.label11.Text = "Finished2:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 27);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 12);
            this.label10.TabIndex = 9;
            this.label10.Text = "Finished1:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 12);
            this.label1.TabIndex = 6;
            this.label1.Text = "RawPipeLength:";
            // 
            // Btn_Read
            // 
            this.Btn_Read.Location = new System.Drawing.Point(438, 262);
            this.Btn_Read.Name = "Btn_Read";
            this.Btn_Read.Size = new System.Drawing.Size(75, 23);
            this.Btn_Read.TabIndex = 29;
            this.Btn_Read.Text = "Read";
            this.Btn_Read.UseVisualStyleBackColor = true;
            this.Btn_Read.Click += new System.EventHandler(this.Btn_Read_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tBox_RawPipeLength);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.tBox_Pipe4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.tBox_Pipe3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.tBox_Pipe2);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.tBox_Pipe1);
            this.groupBox1.Controls.Add(this.tBox_MaterialType);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.tBox_PipeCount);
            this.groupBox1.Controls.Add(this.tBox_OD);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.tBox_WT);
            this.groupBox1.Location = new System.Drawing.Point(21, 16);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(263, 303);
            this.groupBox1.TabIndex = 30;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Write to Control";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.tBox_Finished4);
            this.groupBox2.Controls.Add(this.tBox_Finished1);
            this.groupBox2.Controls.Add(this.tBox_Finished3);
            this.groupBox2.Controls.Add(this.tBox_Finished2);
            this.groupBox2.Location = new System.Drawing.Point(302, 16);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(259, 179);
            this.groupBox2.TabIndex = 31;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Read from Control";
            // 
            // FrmCutting_PC_station
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(595, 357);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Btn_Read);
            this.Controls.Add(this.Btn_Send);
            this.Name = "FrmCutting_PC_station";
            this.Text = "Cutting PC station";
            this.Load += new System.EventHandler(this.FrmCutting_PC_station_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Btn_Send;
        private System.Windows.Forms.TextBox tBox_Pipe4;
        private System.Windows.Forms.TextBox tBox_Pipe3;
        private System.Windows.Forms.TextBox tBox_Pipe2;
        private System.Windows.Forms.TextBox tBox_Pipe1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tBox_PipeCount;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tBox_WT;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tBox_OD;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tBox_MaterialType;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tBox_Finished4;
        private System.Windows.Forms.TextBox tBox_Finished3;
        private System.Windows.Forms.TextBox tBox_Finished2;
        private System.Windows.Forms.TextBox tBox_Finished1;
        private System.Windows.Forms.TextBox tBox_RawPipeLength;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Btn_Read;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}